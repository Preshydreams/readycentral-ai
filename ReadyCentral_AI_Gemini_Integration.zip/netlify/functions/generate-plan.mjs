export default async (req) => {
  if (req.method !== "POST") return new Response(JSON.stringify({error:"Method not allowed"}), {status:405,headers:{"Content-Type":"application/json"}});
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return new Response(JSON.stringify({error:"Gemini API key is not configured."}), {status:500,headers:{"Content-Type":"application/json"}});
  try {
    const body = await req.json();
    const people = Math.max(1, Math.min(20, Number(body.people)||1));
    const days = [3,5,7].includes(Number(body.days)) ? Number(body.days) : 5;
    const home = String(body.home||"house").slice(0,30);
    const needs = String(body.needs||"none").slice(0,30);
    const transport = body.transport === "no" ? "no vehicle" : "has vehicle";
    const prompt = `You are ReadyCentral AI, a calm emergency-preparedness assistant for Central Florida. Give 4-6 concise, practical hurricane/severe-weather preparation suggestions for ${people} people preparing for ${days} days. Home: ${home}. Special needs: ${needs}. Transport: ${transport}. Remind them to check official local alerts, evacuation zones and emergency-management instructions. Never claim to know live weather, current evacuation orders or exact location. Do not replace 911 or official advice.`;
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent", {
      method:"POST", headers:{"Content-Type":"application/json","x-goog-api-key":apiKey},
      body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})
    });
    const data = await response.json();
    if (!response.ok) return new Response(JSON.stringify({error:"Gemini request failed. Check API key, model access and quota."}), {status:502,headers:{"Content-Type":"application/json"}});
    const advice = data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("\n").trim();
    if (!advice) throw new Error("No response text");
    return new Response(JSON.stringify({advice}), {status:200,headers:{"Content-Type":"application/json"}});
  } catch(e) {
    return new Response(JSON.stringify({error:"Unable to generate AI guidance right now."}), {status:500,headers:{"Content-Type":"application/json"}});
  }
};
