# ReadyCentral AI — Gemini-enabled prototype

The Netlify Function calls Gemini server-side using `GEMINI_API_KEY`; the browser never receives the key. The original checklist remains available if AI is unavailable.

Deploy via a Git-connected Netlify site or Netlify CLI so Netlify builds the function. A static drag-and-drop upload may publish only the HTML and omit the function.

Set `GEMINI_API_KEY` as a secret environment variable for Production, then redeploy.

This app does not provide live alerts or current weather. Follow official local emergency management and National Weather Service instructions. Call 911 for immediate danger.
