# ReadyCentral AI

A simple static prototype for household emergency preparedness.

## Deploy
The `index.html` file is at the repository root. For Netlify:
- Branch: `main`
- Build command: leave blank
- Publish directory: `.`

## Current prototype scope
The app generates a starter preparedness checklist using the household inputs. It does not currently connect to Gemini, live weather, or location-based alerts. Do not describe those features as implemented until they are built and tested.
